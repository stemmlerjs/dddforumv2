"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var userController_1 = require("./modules/users/userController");
var userService_1 = require("./modules/users/userService");
var webServer_1 = require("./shared/infra/http/webServer");
var userService = new userService_1.UserService();
var userController = new userController_1.UserController(userService);
new webServer_1.WebServer({ port: 3000 }, userController).start();
