"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompositionRoot = void 0;
var userController_1 = require("../../../modules/users/userController");
var userService_1 = require("../../../modules/users/userService");
var webServer_1 = require("../http/webServer");
var CompositionRoot = /** @class */ (function () {
    function CompositionRoot() {
        this.userService = this.createUserService();
        this.userController = this.createUserController();
        this.webServer = this.createWebServer();
    }
    CompositionRoot.prototype.createUserService = function () {
        return new userService_1.UserService();
    };
    CompositionRoot.prototype.getUserService = function () {
        return this.userService;
    };
    CompositionRoot.prototype.createUserController = function () {
        var userService = this.getUserService();
        return new userController_1.UserController(userService);
    };
    CompositionRoot.prototype.getUserController = function () {
        return this.userController;
    };
    CompositionRoot.prototype.createWebServer = function () {
        var userController = this.getUserController();
        return new webServer_1.WebServer({ port: 3000 }, userController);
    };
    CompositionRoot.prototype.getWebServer = function () {
        return this.webServer;
    };
    return CompositionRoot;
}());
exports.CompositionRoot = CompositionRoot;
