"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessService = void 0;
var exec = require("child_process").exec;
var ProcessService = /** @class */ (function () {
    function ProcessService() {
    }
    ProcessService.killProcessOnPort = function (port, cb) {
        var killCommand = process.platform === "win32"
            ? "netstat -ano | findstr :".concat(port, " | findstr LISTENING")
            : "lsof -i:".concat(port, " -t");
        exec(killCommand, function (error, stdout, stderr) {
            if (error) {
                console.error("Failed to execute the command: ".concat(error.message));
                return cb ? cb() : "";
            }
            if (stderr) {
                console.error("Command execution returned an error: ".concat(stderr));
                return cb ? cb() : "";
            }
            var processId = stdout.trim();
            if (processId) {
                var killProcessCommand = process.platform === "win32"
                    ? "taskkill /F /PID ".concat(processId)
                    : "kill ".concat(processId);
                exec(killProcessCommand, function (error, stdout, stderr) {
                    if (error) {
                        console.error("Failed to kill the process: ".concat(error.message));
                        return cb ? cb() : "";
                    }
                    console.log("Process running on port ".concat(port, " has been killed."));
                    return cb ? cb() : "";
                });
            }
            else {
                console.log("No process found running on port ".concat(port, "."));
                return cb ? cb() : "";
            }
        });
    };
    return ProcessService;
}());
exports.ProcessService = ProcessService;
